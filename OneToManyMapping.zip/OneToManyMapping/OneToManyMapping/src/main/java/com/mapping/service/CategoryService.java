package com.mapping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.model.Category;
import com.mapping.repository.CategoryRepository;

@Service
public class CategoryService {

	@Autowired
    private  CategoryRepository categoryRepository;
    
	/*
	 * public CategoryService(CategoryRepository categoryRepository) {
	 * this.categoryRepository = categoryRepository; }
	 */
    
    //Read
    public List<Category> getAllCategories(){
    	return categoryRepository.findAll();
    }
	
    //Read by id
    public Optional<Category> getCategoryById(int id) {
        return categoryRepository.findById(id);
    }
    
    //Save
    public Category saveCategory(Category category) {
    	return categoryRepository.save(category);
    }
    
    //Update
    public Category updateCategory(int id, Category updatedCategory) {
        Optional<Category> optionalCategory = categoryRepository.findById(id);
        if (optionalCategory.isPresent()) {
            Category category = optionalCategory.get();
             category.setCategoryName(updatedCategory.getCategoryName());                  
            return categoryRepository.save(category);
        }
        return null; 
    }

    // Delete 
    public void deleteCategory(int id) {
        categoryRepository.deleteById(id);
    }
    
    
    //List<Category> categoriesWithName = categoryRepository.findByName("Men");
   
}
