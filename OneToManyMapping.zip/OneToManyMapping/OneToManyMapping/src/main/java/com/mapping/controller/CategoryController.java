package com.mapping.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mapping.model.Category;
import com.mapping.service.CategoryService;

@RestController
@RequestMapping("/categories")
public class CategoryController {
    
	@Autowired
	private  CategoryService categoryService;
	
	@PostMapping("/save")
	public ResponseEntity<Category> createCategory(@RequestBody Category category){
		Category createdCategory = categoryService.saveCategory(category);
		return new ResponseEntity<>(createdCategory, HttpStatus.OK);
	}
	
    
	@GetMapping
	public ResponseEntity<List<Category>> getAllCategories(){
		List<Category> categories = categoryService.getAllCategories();
		return new ResponseEntity<>(categories, HttpStatus.OK);
	}
	
	 @GetMapping("/{id}")
	    public ResponseEntity<Category> getCategoryById(@PathVariable int id) {
	        Optional<Category> category = categoryService.getCategoryById(id);
	        return category.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
	                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	    }

	  
	    @PutMapping("/{id}")
	    public ResponseEntity<Category> updateCategory(@PathVariable int id, @RequestBody Category category) {
	        Category updatedCategory = categoryService.updateCategory(id, category);
	        return updatedCategory != null ?
	                new ResponseEntity<>(updatedCategory, HttpStatus.OK) :
	                new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }

	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteCategory(@PathVariable int id) {
	        categoryService.deleteCategory(id);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	    
	    
	    
	    
	    
	/*
	 * public CategoryController(CategoryService categoryService) {
	 * this.categoryService = categoryService; }
	 * 
	 * @GetMapping public List<Category> getAllCategory(){ return
	 * categoryService.getAllCategories(); }
	 * 
	 * @GetMapping("/{id}") public Category getCategryById(@PathVariable int id) {
	 * return categoryService.getCategoryById(id); }
	 * 
	 * 
	 * @PostMapping("/save") public Category saveCategory(@RequestBody Category
	 * category) { return categoryService.saveCategory(category); }
	 */
}
