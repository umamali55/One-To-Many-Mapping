package com.mapping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mapping.model.Product;
import com.mapping.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
    private  ProductRepository productRepository;
    
	/*
	 * public ProductService(ProductRepository productRepository) {
	 * this.productRepository = productRepository; }
	 */
    
	//Read
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    //Read by id
    public Optional<Product> getProductById(int id) {
        return productRepository.findById(id);
    }
   
    //Save
    public Product saveProduct(Product product) {
    	return productRepository.save(product);
    }
    
    //Update
    public Product updateProduct(int id, Product updatedProduct) {
        Optional<Product> optionalProduct = productRepository.findById(id);
        if (optionalProduct.isPresent()) {
            Product product = optionalProduct.get();
            product.setCategory(updatedProduct.getCategory());         
            
            return productRepository.save(product);
        }
        return null; 
    }

    // Delete 
    public void deleteProduct(int id) {
        productRepository.deleteById(id);
    }
    
    //List<Product> productsInCategory = productRepository.findByCategory(category);
    
}
